import java.util.Scanner;
public class Soma{
public static void main(String[] args) {
	
	
	Scanner ler = new Scanner (System.in);

	int A,B, SOMA;

	System.out.println("Digite um numero");
	A=ler.nextInt();
	System.out.println("Digite um numero");
	B=ler.nextInt();

	SOMA=A+B;

	System.out.println("Resultado: " +SOMA);	
}
}