import java.util.Scanner;
public class Litros{
public static void main(String[] args) {
	
	Scanner ler = new Scanner (System.in);

		int tempo, velocidade;
		double litros;

		System.out.println("Digite a quantidade em horas gasta para chegar no seu destino: ");
		tempo=ler.nextInt();
		System.out.println("Digite a velocidade em KM/h gasta para chegar no seu destino: ");
		velocidade=ler.nextInt();

		litros=tempo*velocidade;

		System.out.println("Quantidades de litros necessario " +litros + "l");
		

			
}
}