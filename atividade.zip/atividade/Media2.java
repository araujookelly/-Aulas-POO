import java.util.Scanner;
public class Media2{
public static void main(String[] args) {

	Scanner ler = new Scanner (System.in);

	double A,B,C, MEDIA;

	System.out.println("Nota 1");
	A=ler.nextDouble();
	System.out.println("Nota 2");
	B=ler.nextDouble();
	System.out.println("Nota 3");
	C=ler.nextDouble();

	MEDIA=((A*2)+(B*3)+(C*5))/3;

	System.out.println("Media:" +MEDIA);

	
	
}
	
}