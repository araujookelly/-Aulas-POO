import java.util.Scanner;
public class Produto{
public static void main(String[] args) {

	Scanner ler = new Scanner (System.in);

	int N1,N2,PROD;

	System.out.println("N1:");
	N1=ler.nextInt();
	System.out.println("N2:");
	N2=ler.nextInt();

	PROD=N1*N2;

	System.out.println("Produto: " +PROD);
}
}
