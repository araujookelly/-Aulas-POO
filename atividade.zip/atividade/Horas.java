import java.util.Scanner;
public class Horas{
public static void main(String[] args) {
 
		Scanner ler = new  Scanner (System.in);
		int  num , h, m, s;

		System.out.println("Digite a quantidade de segundos:");
		num=ler.nextInt();

		h= num/3600;
		m=(num%360)/60;
		s=(num%3600)%60;
		System.out.println(h +" : "+m +" : "+ s);

    }
}