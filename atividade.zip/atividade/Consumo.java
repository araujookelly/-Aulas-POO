import java.util.Scanner;
public class Consumo{
public static void main(String[] args) {
	
	Scanner ler = new Scanner (System.in);

	double distancia, totalCom, consumo;

	System.out.println("Digite a distancia em KM pecorrida pelo seu veiculo: ");
	distancia=ler.nextDouble();
	System.out.println("Digite o total de combustivel gasto em litros do seu altomovel: ");
	totalCom=ler.nextDouble();

	consumo=distancia*totalCom;

	System.out.println("Consumo medio " +consumo +"KM/L");
}
}