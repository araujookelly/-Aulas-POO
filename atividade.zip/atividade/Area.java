import java.util.Scanner;
public class Area{
public static void main(String[] args) {
	

	Scanner ler = new Scanner (System.in);

	double a,b,c,tri,cir,tra,qua,ret;

	System.out.println("Digite A:");
	a=ler.nextDouble();
	System.out.println("Digite B:");
	b=ler.nextDouble();
	System.out.println("Digite C:");
	c=ler.nextDouble();

	tri=a*c/2;
	System.out.println("Area do triangulo: " +tri);

	cir=3.14159*(c*c);
	System.out.println("Area do circulo: " +cir);

	tra=((a+b)*c)/2;
	System.out.println("Area do trapezio: " +tra);

	qua=b*b;
	System.out.println("Area do quadrado: " +qua);

	ret=a*b;
	System.out.println("Area do retangulo: " +ret);
	

	}

}