import java.util.Scanner;
public class Bonus{
public static void main(String[] args){

	Scanner ler = new Scanner (System.in);

	char nome;
	double salario,sararioBonus;
	int totalVendas;

	System.out.println("Digite o nome do funcionario: ");
	nome=ler.next();
	System.out.println("Digite salario fixo do funcionario: ");
	salario=ler.nextDouble();
	System.out.println("Digite numero de vendas do funcionario: ");
	totalVendas=ler.nextInt();

	sararioBonus=(totalVendas*0.15)+salario;

	System.out.println("Salario a receber: ");

}
}