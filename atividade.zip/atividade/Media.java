import java.util.Scanner;
public  class Media{
public static void main(String[] args) {

	Scanner ler = new Scanner (System.in);

	double n1,n2,media;

	System.out.println("Digite a primeira nota: ");
	n1=ler.nextDouble();
	System.out.println("Digite a segunda nota: ");
	n2=ler.nextDouble();

	media=((n1*3.5)+(n2*7.5))/2;

	System.out.println("Media:" +media);
	if (media>=11) {
		System.out.println("Valor invalido!");
		
	}
		
	}
}