import java.util.Scanner;
public class Par{
public static void main(String[] args) {
	
	Scanner ler = new Scanner (System.in);

	int num,i;


	for(i=0;i<100;i++){
		num=1%2;
		if(num%2==0){
			System.out.println("Números pares:");
		}
	}
}
}