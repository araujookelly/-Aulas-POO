import java.util.Scanner;
public class Maior{
public static void main(String[] args) {
	

	Scanner ler = new Scanner (System.in);

	int a,b,c;

	System.out.println("Digite a: ");
	a=ler.nextInt();
	System.out.println("Digite b: ");
	b=ler.nextInt();
	System.out.println("Digite c: ");
	c=ler.nextInt();

	if(a>b && a>c){
		System.out.println("A é mair que B e C");
	}
	else 
	if(b>a && b>c){
		System.out.println("B é mair que A e C");
	}
	else
	if(c>a && c>b){
		System.out.println("C é mair que A e B");
	}
	
}
}