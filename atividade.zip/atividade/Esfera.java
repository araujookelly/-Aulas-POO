import java.util.Scanner;
public class Esfera{
public static void main(String[] args) {
	
	Scanner ler = new Scanner (System.in);

	double pi=3.14159, raio, volume;

	System.out.println("Digite o raio:");
	ler=nextDouble();

	volume=(4/3)*pi*(raio*raio*raio);

	System.out.println("Volume da Esfera: " +volume);
}
	
}