import java.util.Scanner;
public class SomadeDois{
public static void main (String[] args){

Scanner ler = new Scanner (System.in);

int A,B,X;

System.out.println("Digite o primeiro número");
A=ler.nextInt();
System.out.println("Digite o segundo número");
B=ler.nextInt();

X=A+B;

System.out.println("Resultado da Soma: " +X);

}
}