import java.util.Scanner;
public Idade{
public static void main(String[] args) {
	

	Scanner ler = new Scanner (System.in);

	int id, ano, meses, dias;

	System.out.println("Digite sua quantidade de dias existentes: ");
	id=ler.nextInt();

	ano= id/365;
	meses=(id%365)/30;
	dias=(id%365)%30;

	System.out.println(ano +"ano(s)");
	System.out.println(meses +"mes(ses)");
	System.out.println(dias +"dia(s)");
	
}
}