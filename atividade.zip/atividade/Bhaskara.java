import java.util.Scanner;
public class Bhaskara{
public static void main(String[] args) {
	

	Scanner ler = new Scanner (System.in);


	int a,b,c,d;