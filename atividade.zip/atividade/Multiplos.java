import java.util.Scanner;
public class Multiplos{
public static void main(String[] args) {
	
	Scanner ler = new Scanner (System.in);

	int a,b;
	

	System.out.println("Digite um numero:");
	a=ler.nextInt();
	System.out.println("Digite um numero");
	b=ler.nextInt();

	if((a%b==0)|| (b%a==0)){
		System.out.println("São Multiplos");
	}else{
		System.out.println("Nao são Multiplos");
	}
}
}
