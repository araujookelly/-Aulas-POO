import java.util.Scanner;
public class SomaRaio{
public static void main (String[] args){

Scanner ler = new Scanner (System.in);

double  area, raio;
System.out.println("Digite o raio");
raio =ler.nextDouble();

area=3.14 *(raio*raio);

System.out.println("Area : " + area);
}
}
