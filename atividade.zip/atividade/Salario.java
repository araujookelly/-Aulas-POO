import java.util.Scanner;
public class Salario{
public static void main(String[] args) {

	Scanner ler = new Scanner (System.in);

	int numFunc,horaTra;
	double salFunc,valHora;

	System.out.println("Digite o número do funcionario:");
	numFunc=ler.nextInt();
	System.out.println("Digite as horas trabalhadas do funcionao: ");
	horaTra=ler.nextInt();
	System.out.println("Digite o valor da hora do funcionao");
	valHora=ler.nextDouble();

	salFunc=horaTra*valHora;

	System.out.println("Salario: " +salFunc);
		
	}
		
	}