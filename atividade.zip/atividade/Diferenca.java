import java.util.Scanner;
public class Diferenca{
public static void main(String[] args) {

	Scanner ler = new Scanner (System.in);

	int A,B,C,D, DIF;

	System.out.println("Digite A:");
	A=ler.nextInt();
	System.out.println("Digite B:");
	B=ler.nextInt();
	System.out.println("Digite C:");
	C=ler.nextInt();
	System.out.println("Digite D:");
	D=ler.nextInt();

	DIF=(A*B-C*D);

	System.out.println("Diferenca: " +DIF);

		
	}
	
}