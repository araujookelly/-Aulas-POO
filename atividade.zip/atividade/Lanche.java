import java.util.Scanner
public class Lanche{
public static void main(String[] args) {
	
	Scanner ler = new Scanner (System.in);

	int cod,quant;
	double preco,total

	System.out.println("Digite o codigo:");
	cod=ler.nextInt();
	System.out.println("Digite a quantidade:");
	quant=ler.nextInt;

	switch(cod){
		case : 1; preco=4.00;break;
		case : 2; preco=4.50;break;
		case : 3; preco=5.00;break;
		case : 4; preco=2.00;break;
		case : 5; preco=1.50;break;
		default: System.out.println("Produto Invalido");break;

	}

	total=cod*quant;

	System.out.println("Total R$:" +total);

}

}